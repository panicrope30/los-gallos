CREATE TABLE carrerautobuse.usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombreuser VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL
);

/ / elaborado por brayan rosas