<?php
error_reporting(0);
//incluir conexion a la bd
include 'include/conexion.php';

$mensajeLogin;
//recuperar datos
if(isset($_POST['iniciar'])){
    $remail = $conecta->real_escape_string($_POST['email']);
    $rpass = $conecta->real_escape_string($_POST['password']);
    $consulta = "SELECT * FROM `usuario` WHERE email = '$remail' AND password = '$rpass'";

    if($Resultado = $conecta->query($consulta)){
        while($row = $Resultado->fetch_array()){
            $Emailok = $row['email'];
            $passwordok = $row['password'];
        }
        $Resultado->close();
    }

    $conecta->close();

    if(isset($remail) && isset($rpass)){
        if($remail == $Emailok && $rpass == $passwordok){

            $_SESSION['login'] = TRUE;
            $_SESSION['usuario'] = $usuario;
            header("location:carrera de micros.html");
        }
        else{
            $mensajeLogin.="<p>Tu inicio se sesion no se realizó con exito</p>";
        }
    }
    else{
        $mensajeLogin.="<p>Tu inicio se sesion no se realizó con exito</p>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="loginstyle.css">
    
</head>
<body>
    <div class="container">

      <div class="title">
            <h2 class="text-center">
                INICIAR SESIÓN
            </h2>
        </div>

            <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">

            <div class="row mt-2">
                <div class="col sm-10 md-10 lg-10">
                    <input type="email" name = "email" placeholder = "email" class="form-control" required>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col sm-10 md-10 lg-10">
                    <input type="password" name = "password" placeholder = "contraseña" class="form-control" required>
                </div>
            </div>

            <div class="row mt-2">
               <div class="col sm-10 md-10 lg-10">
                    <input type="submit" name = "iniciar" value = "iniciar" placeholder = "LOG IN" class="form-control bg-primary" required>
               </div>
            </div>
            <center>
            <?php echo $mensajeLogin;?>
            </center>
            </form>
    </div>
</body>
</html>

<!--HECHO POR
BRAYAN ROSAS COLIN
MARÍA BELÉN MARTINEZ GUTIERREZ