<?php 
include 'include/conexion.php';

$mensajeRegistro = " ";

include 'include\controlador.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="registro_style.css">
    <title>REGISTRO</title>
</head>
<body>

    <header>
        <nav>
            <a href="login.php">IR AL LOGIN</a>
        </nav>
    </header>


<div class="container">
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
        <div class="title">
            <h2 class="text-center">
                REGISTRO
            </h2>
        </div>
           <div class="row mt-2">
                <div class="col-sm-12 col-md-12 col-lg-12">
                <input type="text" name = "username" placeholder = "username" class="form-control" required>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-sm-12 col-md-6 col-lg-6">
                <input type="Email" name = "Email" placeholder = "Email" class="form-control" required>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6">
                <input type="password" name = "password" placeholder = "password" class="form-control" required>
                </div>
            </div>

            <div class="botton">
            <div class="row mt-2">
                <div class="col-sm-12 col-md-12 col-lg-12 ">
                <input type="submit" name = "registrar" value= "registrar" placeholder = "registrar"class="form-control bg-primary" required>
                </div>
                
            </div>
            </div>
    </form>
    <?php echo $mensajeRegistro; ?>
    
</div>

</body>
</html>

