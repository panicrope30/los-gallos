<?php
//verificar que exista un boton de enviar
if(isset($_POST['registrar'])){


    $NombreUser = $conecta->real_escape_string($_POST['username']);
    $Email = $conecta->real_escape_string($_POST['Email']);
    $Password = $conecta->real_escape_string($_POST['password']);

    $insertarDatos ="INSERT INTO `usuario`(`id_usuario`, `nombreuser`, `email`, `password`) VALUES (null,'$NombreUser','$Email','$Password')";
    $guardando = $conecta->query($insertarDatos);

    if($guardando > 0){
        $mensajeRegistro.="<h5 class='text-success'>Tu registro se realizó con exito</h5>";
        
    }
    else{
        $mensajeRegistro.="<h3 class='text-danger'>Error al registrar usuario</h3>";
    }
}

?>